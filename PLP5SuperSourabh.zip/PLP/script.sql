CREATE TABLE USERS (username varchar2(20),password varchar2(20),role varchar2(20),mobile_no varchar2(20));


insert into users values('lalita','123','admin',7798813392);
insert into users values('Mohit','456','admin',7798853392);
insert into users values('Priya','asd','Executive',7899879878);

create table flightinformation (flightno varchar2(5) primary key, airline varchar2(50),
dep_city varchar2(50),arr_city varchar2(50),dep_date date,arr_date date ,dep_time varchar2(10),
arr_time varchar2(10),firstSeats number,firstseatfare number(7,2),BussSeats number,BussSeatsFare
number(7,2));

INSERT INTO FLIGHTINFORMATION (flightno, airline,
dep_city,arr_city,dep_date,arr_date,dep_time,
arr_time,firstSeats,firstseatfare,BussSeats,BussSeatsFare) VALUES('12345','Jet','Mumbai','Chennai','09/09/2016',
'09/19/2016','EIGHT','NINE',78,7900,67,6900); 

INSERT INTO FLIGHTINFORMATION (flightno, airline,
dep_city,arr_city,dep_date,arr_date,dep_time,
arr_time,firstSeats,firstseatfare,BussSeats,BussSeatsFare)  VALUES('12645','Jee','Mumbai','Chennai','09/09/2016',
'09/19/2016','EIGHT','NINE',78,7609,67,6090); 

INSERT INTO FLIGHTINFORMATION  (flightno, airline,
dep_city,arr_city,dep_date,arr_date,dep_time,
arr_time,firstSeats,firstseatfare,BussSeats,BussSeatsFare) VALUES('12945','GoAir','Chennai','Kolkata','09/08/2016',
'09/19/2016','EIGHT','NINE',89,5000,67,2000); 

INSERT INTO FLIGHTINFORMATION (flightno, airline,
dep_city,arr_city,dep_date,arr_date,dep_time,
arr_time,firstSeats,firstseatfare,BussSeats,BussSeatsFare)  VALUES('18645','IndiGo','Mumbai','Delhi','09/09/2016',
'09/24/2016','EIGHT','NINE',78,7009,67,6900); 

INSERT INTO FLIGHTINFORMATION (flightno, airline,
dep_city,arr_city,dep_date,arr_date,dep_time,
arr_time,firstSeats,firstseatfare,BussSeats,BussSeatsFare)  VALUES('15645','TruJet','Tamilnadu','Delhi','09/09/2016',
'09/24/2016','EIGHT','NINE',78,7009,67,6900); 

CREATE TABLE BOOKINGINFORMATION(
booking_id varchar2(5)  primary key,
cust_email varchar2(50),
no_of_passengers number(1),
class_type varchar2(50),
total_fare number(8,2),
seat_number varchar2(255),
credit_card_info varchar2(20),
src_city varchar2(50),
dest_city varchar2(50),
flightno varchar2(5),
foreign key(flightno) references flightinformation(flightno)) ;

create table airport(airport_name varchar2(20), abbreviation varchar2(20),location varchar2(20));


select airline, sum(firstseats) as seats,sum (BussSeats) as seats_1 from FLIGHTINFORMATION group by airline;
select airline,flightno ,sum(bussSeats) from flightinformation where dep_city='Mumbai' and dep_date='09/09/2016' group by airline,flightno;

===============================================================================

create table Users (username varchar2(20), password varchar2(20), role varchar2(10), mobile_no number);

create table Airport (AirportName varchar2(20), Abbreviation varchar2(5), Location varchar2(40));





create sequence bookingId_sequence;

create sequence seatNumbersFirstClass_sequence;

create sequence seatNumbersBussClass_sequence;



insert into users values('Admin','Admin','Admin',9999999999);
insert into users values('executive','executive','executive',9999999999);