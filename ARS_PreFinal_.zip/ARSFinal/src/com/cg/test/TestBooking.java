package com.cg.test;

import static org.junit.Assert.*;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.BookingInfoServiceImpl;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IBookingInfoService;
import com.cg.service.IFlightInfoService;

public class TestBooking {

	static IBookingInfoService bookingInfoService= null;
	static IFlightInfoService flightInfoService=null;
	static BookingInformationBean bean=null;
	static FlightInformationBean fbean=null;
			
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		bookingInfoService=new BookingInfoServiceImpl();
		flightInfoService=new FlightInfoServiceImpl();
		bean=new BookingInformationBean();
		fbean=new FlightInformationBean();
		
		bean.setClassType("firstclass");
		bean.setCreditCardInformation("baba");
		bean.setCustomerEmail("abc@g.com");
		bean.setNumberOfPassengers(3);
		
		fbean=flightInfoService.viewParticularFlightInfo("33333");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		bookingInfoService=null;
		flightInfoService=null;
		bean=null;
		fbean=null;
	}



	@Test
	public void testBookingSuccessful()  {
		try {
		
			assertNotNull(bookingInfoService.confirmBooking(bean, fbean));
			
			
		} catch (ARSException e) {
			//System.out.println("Booking Failed in junit"+e.getMessage());
		}
	}
	
	@Test
	public void testBookingUnsuccessful()  {
		try {
			fbean.setFlightNumber("46785");
			assertNull(bookingInfoService.confirmBooking(bean, fbean));
			
			
		} catch (ARSException e) {
			//System.out.println("Booking Failed in junit"+e.getMessage());
		}
	}

}
