package com.cg.ars.bean;

public class AirportBean {
	
	private String airportName;
	private String abbreviation;
	private String location;
	public AirportBean() {
		super();
	}
	public AirportBean(String airportName, String abbreviation, String location) {
		super();
		this.airportName = airportName;
		this.abbreviation = abbreviation;
		this.location = location;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "AirportBean [airportName=" + airportName + ", abbreviation="
				+ abbreviation + ", location=" + location + "]";
	}
	
	

}