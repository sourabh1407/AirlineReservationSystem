package com.cg.ars.dao;

public interface ICutomerQueryMapper {
	
	public static final String DISPLAY_BOOKING ="SELECT booking_id,cust_email,no_of_passengers,class_type,total_fare,seat_number,credit_card_info,src_city,dest_city,flightno FROM bookinginformation WHERE booking_id=?";
	
	public static final String CONFIRM_BOOKING = "INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_BOOKING="UPDATE bookinginformation SET cust_email=?  where booking_id=?";
	
	public static final String CANCEL_BOOKING="DELETE FROM bookinginformation WHERE booking_id=?";
	
	public static final String BOOKING_ID_SEQUENCE="SELECT bookingId_sequence.NEXTVAL FROM DUAL";
	
	public static final String FIRST_CLASS_SEQUENCE="SELECT seatNumbersFirstClass_sequence.NEXTVAL FROM DUAL";
	
	public static final String BUSINESS_CLASS_SEQUENCE="SELECT seatNumbersBussClass_sequence.NEXTVAL FROM DUAL";

	public static final String VIEW_FLIGHTS ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation WHERE dep_city=? AND arr_city=?";

	public static final String REDUCE_FIRST_SEATS="UPDATE flightinformation SET FirstSeats=FirstSeats-1 where flightno=?";
	
	public static final String REDUCE_BUSS_SEATS=" UPDATE flightinformation SET   BussSeats=BussSeats-1  where flightno=?";
	
    public static final String INC_FIRST_SEATS="UPDATE flightinformation SET FirstSeats=FirstSeats+1 where flightno=?";
	
	public static final String INC_BUSS_SEATS=" UPDATE flightinformation SET   BussSeats=BussSeats+1  where flightno=?";
}
