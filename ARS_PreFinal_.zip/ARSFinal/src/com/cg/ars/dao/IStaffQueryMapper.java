
package com.cg.ars.dao;

public interface IStaffQueryMapper {
	
	public static final String VERIFY_USER = "SELECT username FROM users WHERE (username=? and password=? and role=?)";
	
	public static final String VIEW_FLIGHT_INFORMATION ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation";
	
	public static final String VIEW_PARTICULAR_FLIGHT_INFORMATION ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation WHERE flightno=?";
	
	public static final String ADD_FLIGHT = "INSERT INTO flightinformation VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_FLIGHT_INFORMATION ="UPDATE flightinformation SET airline=?,dep_city=?,arr_city=?, dep_date=?, arr_date=?, dep_time=?, arr_time=?, FirstSeats=?, FirstSeatFare=?, BussSeats=?, BussSeatsFare=?  where flightno=?";
	
	public static final String DELETE_FLIGHT_INFORMATION="delete from flightinformation where flightno=?";
	
	public static final String VIEW_OVER_ALL_OCCUPANCY ="SELECT flightno,airline,(FirstSeats+BussSeats)AS occupancy FROM flightinformation WHERE dep_city=? AND arr_city=?";
	
	public static final String VIEW_PERIOD_OCCUPANCY ="SELECT (FirstSeats+BussSeats)AS occupancy FROM flightinformation WHERE flightno=? AND dep_date=?";
			
			
			
			//"SELECT (FirstSeats+BussSeats)AS occupancy FROM flightinformation WHERE flightno=? AND dep_date=?";
	 //"update flightinformation set DEP_DATE=?, ARR_DATE=?,DEP_TIME=?,ARR_TIME=?,FIRSTSEATS=?, FIRSTSEATFARE=?,BUSSSEATS=?,BUSSSEATFARE=? where FLIGHTNO=?"
}
