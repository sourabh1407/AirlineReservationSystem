package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class UserDaoImpl implements IUserDao {

	@Override
	public boolean isValidUser(String userName, String password, String role)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean isValid = false;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VERIFY_USER);

			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			preparedStatement.setString(3, role);

			resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next() == false) {
				isValid = false;
			} else {
				isValid = true;
			}

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No such user " + e.getMessage());
		}
		return isValid;
	}

}
