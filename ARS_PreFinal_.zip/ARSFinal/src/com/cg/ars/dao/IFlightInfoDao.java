/**
 * 
 */
package com.cg.ars.dao;



import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;



/**
 * @author CAPG
 *
 */
public interface IFlightInfoDao {

	public List<FlightInformationBean> viewAllFlightInformation()  throws ARSException;

	public FlightInformationBean viewParticularFlightInfo(String flightNumber)throws ARSException;

	public boolean addFlight(FlightInformationBean bean) throws ARSException;

	public boolean deleteFlight(String FlightNo)throws ARSException;
	
	public FlightInformationBean updateFlightInformation(FlightInformationBean flightInfoBean) throws ARSException;
	
	public HashMap<String,String> viewOverAllOccupancy(String sourceCity,String destinationCity) throws ARSException;
	
	public int viewPeriodOccupancy(String flightNumber,LocalDate fromDate,LocalDate toDate) throws ARSException;

}
