package com.ars.service;

import java.util.List;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.exception.ARSException;

public interface IArsService {

	public BookingInformationBean confirmBooking(BookingInformationBean bookingInformationBean) throws ARSException;

	public BookingInformationBean displayBooking(String bookingId) throws ARSException;

	public BookingInformationBean cancelBooking(String bookingId) throws ARSException;
	
	public BookingInformationBean updateBooking(String bookingId,String cust_email) throws ARSException;

	public List<FlightInformationBean> viewFlights(String Source,String destination)throws ARSException;
	
	public FlightInformationBean viewFlight(String flightNumber)throws ARSException;
}
