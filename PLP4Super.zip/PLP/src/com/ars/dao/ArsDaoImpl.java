package com.ars.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.exception.ARSException;

@Repository
@Transactional
public class ArsDaoImpl implements IArsDao {

	@PersistenceContext
	EntityManager entityManager;
	
	
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public BookingInformationBean confirmBooking(
			BookingInformationBean bookingInformationBean) throws ARSException {
		BookingInformationBean bean=new BookingInformationBean();
		try {

			
			FlightInformationBean fbean=entityManager.find(FlightInformationBean.class, bookingInformationBean.getFlightNumber());
			bean.setClassType(bookingInformationBean.getClassType());
			bean.setCreditCardInformation(bookingInformationBean.getCreditCardInformation());
			bean.setCustomerEmail(bookingInformationBean.getCustomerEmail());
			bean.setDestinationCity(fbean.getArrivalCity());
			bean.setFlightNumber(bookingInformationBean.getFlightNumber());
			int numberOfPassengers=bookingInformationBean.getNumberOfPassengers();
			bean.setNumberOfPassengers(numberOfPassengers);
			
			bean.setSourceCity(fbean.getDepartureCity());
		

		
			if (bookingInformationBean.getClassType().equalsIgnoreCase("firstclass")) {
				
				String seatNumbers="";
				int firstSeats=fbean.getFirstClassSeats()-bookingInformationBean.getNumberOfPassengers();
				if (firstSeats>=0) {
					bean.setTotalFare(bookingInformationBean.getNumberOfPassengers()*fbean.getFirstClassSeatFare());
					int fseats=fbean.getFirstClassSeats();
					for (int i = 0; i < numberOfPassengers; i++) {
						
						seatNumbers=seatNumbers+" "+String.valueOf(fseats);
						--fseats;
					}
					fbean.setFirstClassSeats(firstSeats);
					bean.setSeatNumbers(seatNumbers);
					
				}
				else{
					return null;
		
				}
				
			} 
			
			
			else {
				
				String seatNumbers="";
				int bussSeats=fbean.getBussinessClassSeats()-bookingInformationBean.getNumberOfPassengers();
				if (bussSeats>=0) {
					bean.setTotalFare(bookingInformationBean.getNumberOfPassengers()*fbean.getBussinessClassSeatsFare());
					int bseats=fbean.getBussinessClassSeats();
					for (int i = 0; i < numberOfPassengers; i++) {
						
						seatNumbers=seatNumbers+" "+String.valueOf(bseats);
						--bseats;
					}
					fbean.setBussinessClassSeats(bussSeats);
					bean.setSeatNumbers(seatNumbers);
					
				}
				else{
					return null;
					
				}
			}
			
			Query query =entityManager.createNativeQuery("Select bookingId_sequence.NEXTVAL from dual");
			bean.setBookingId(String.valueOf(query.getSingleResult()));
			

			entityManager.persist(bean);
			entityManager.merge(fbean);
			entityManager.flush();
			
		} catch (Exception e) {

			throw new ARSException("Exception in confirmBooking() in dao layer "+e.getMessage());
		}
		
		return bean;
	}

	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {

		BookingInformationBean bean=null;
		try {
			bean = entityManager.find(BookingInformationBean.class, bookingId);
		} catch (Exception e) {
			throw new ARSException("Exception in displayBooking() in dao layer "+e.getMessage());
		}
		
		return bean;
	}

	@Override
	public BookingInformationBean cancelBooking(String bookingId)
			throws ARSException {
		BookingInformationBean bean= entityManager.find(BookingInformationBean.class, bookingId);
		FlightInformationBean fbean= entityManager.find(FlightInformationBean.class, bean.getFlightNumber());
		
		try {
			
			if(bean!=null)
			{	
				entityManager.remove(bean);
				if(bean.getClassType().equalsIgnoreCase("firstclass"))
				{	
					int firstClassSeats=bean.getNumberOfPassengers()+fbean.getFirstClassSeats();
					fbean.setFirstClassSeats(firstClassSeats);
				}
				else
				{
					int bussClassSeats=bean.getNumberOfPassengers()+fbean.getBussinessClassSeats();
					fbean.setFirstClassSeats(bussClassSeats);
				}
				entityManager.merge(fbean);
				entityManager.flush();
				
			}
		} catch (Exception e) {
			throw new ARSException("Exception in cancelBooking() in dao layer "+e.getMessage() );
		}
		return bean;
	}

	@Override
	public BookingInformationBean updateBooking(String bookingId,
			String cust_email) throws ARSException {
		try {
			BookingInformationBean bean = entityManager.find(BookingInformationBean.class, bookingId);
			if(bean!=null)
			{
				bean.setCustomerEmail(cust_email);
				entityManager.merge(bean);
				entityManager.flush();
				return bean;
			}
		} catch (Exception e) {
			throw new ARSException("Exception in updateBooking() in dao layer "+e.getMessage() );
		}
		return null;
	}

	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		List<FlightInformationBean> list =null;
		try {
			TypedQuery<FlightInformationBean> qry = entityManager.createQuery("from FlightInformationBean where departureCity=:Source and arrivalCity=:destination", FlightInformationBean.class);
			qry.setParameter("Source", Source);
			qry.setParameter("destination", destination);
			//System.out.println(qry.getFirstResult());
			//System.out.println(qry.getSingleResult());
			list = qry.getResultList();
			System.out.println("dao list "+list);
		} catch (Exception e) {
			throw new ARSException("Exception in viewFlights() in dao layer "+e.getMessage() );
		}
		
		return list;
	}

	@Override
	public FlightInformationBean viewFlight(String flightNumber)
			throws ARSException {
		try {
			FlightInformationBean fbean=entityManager.find(FlightInformationBean.class, flightNumber);
			if(fbean!=null)
			{
				return fbean;
			}
		} catch (Exception e) {
			throw new ARSException("Exception in viewFlight() in dao layer "+e.getMessage() );
		}
		return null;
	}

}
