package com.ars.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.exception.ARSException;
import com.ars.service.IArsService;

@Controller
public class ArsController {

	@Autowired
	IArsService arsService;

	public IArsService getArsService() {
		return arsService;
	}

	public void setArsService(IArsService arsService) {
		this.arsService = arsService;
	}

	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return ("index");
	}
	
	@RequestMapping("/book")
	public String viewAll()
	{
		return ("viewAll");
	}
	
	@RequestMapping("/display")
	public String display()
	{
		return ("viewTicket");
	}
	
	@RequestMapping("/delete1")
	public String delete1()
	{
		return ("viewDelete");
	}
	
	@RequestMapping("/modify")
	public String modify()
	{
		return ("modifyTicket");
	}
	
	@RequestMapping("/viewAllFlights")
	public ModelAndView viewAllFlights(@RequestParam("departureCity")String depCity,@RequestParam("arrivalCity")String arrCity)
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<FlightInformationBean> list=arsService.viewFlights(depCity, arrCity);
			mv.setViewName("viewAll");
			if (!list.isEmpty()) {
				
				mv.addObject("list", list);
				mv.addObject("message", "Flight Details  ");
			} else {
				mv.addObject("message", "No Flights found!!!");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","viewAllFlights() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping("/viewBooking")
	public ModelAndView viewBooking(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		try {
			BookingInformationBean bean=arsService.displayBooking(bookingId);
			mv.setViewName("viewTicket");
			if (bean!=null) {
				
				mv.addObject("bean", bean);
				mv.addObject("message", "Ticket Details  ");
			} else {
				mv.addObject("message", "No Ticket found");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","viewBooking() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping("/bookFlight")
	public ModelAndView bookFlight(@RequestParam("flightNumber")String flightno)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			FlightInformationBean fbean=arsService.viewFlight(flightno);
			mv.setViewName("bookTicket");
			if (fbean!=null) {
				mv.addObject("fbean", fbean);
				mv.addObject("message", "Flight Details");
			} else {
				mv.addObject("message", "Flight not found");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","bookFlight() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping(value="/confirmBooking",method=RequestMethod.POST)
	public ModelAndView confirmBooking(@ModelAttribute("bookBean")BookingInformationBean bean)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bookedbean=arsService.confirmBooking(bean);
			mv.setViewName("success");
			if (bookedbean!=null) {
				mv.addObject("bean", bookedbean);
				mv.addObject("message", "Booked Sucessfully");
			} else {
				mv.addObject("message", "Booking Failed");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","confirmBooking() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bookedbean=arsService.cancelBooking(bookingId);
			mv.setViewName("success");
			if (bookedbean!=null) {
				mv.addObject("bean", bookedbean);
				mv.addObject("message", "Booking Cancelled Sucessfully");
			} else {
				mv.addObject("message", "Booking Cancellation Failed");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","delete() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping("/update")
	public ModelAndView update(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bookedbean=arsService.displayBooking(bookingId);
			mv.setViewName("updateTicket");
			if (bookedbean!=null) {
				mv.addObject("bean", bookedbean);
				mv.addObject("message", "Booking Information");
			} else {
				mv.addObject("message", "Booking Info not found");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","update() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	@RequestMapping("/updateTicket")
	public ModelAndView updateTicket(@RequestParam("bookingId")String bookingId,@RequestParam("customerEmail")String email)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bookedbean=arsService.updateBooking(bookingId, email);
			mv.setViewName("success");
			if (bookedbean!=null) {
				mv.addObject("bean", bookedbean);
				mv.addObject("message", "Email updated Sucessfully");
			} else {
				mv.addObject("message", "Email updation Failed");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","updateTicket() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	@RequestMapping("/viewDelete")
	public ModelAndView viewDelete(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		try {
			BookingInformationBean bean=arsService.displayBooking(bookingId);
			mv.setViewName("viewDelete");
			if (bean!=null) {
				
				mv.addObject("bean", bean);
				mv.addObject("message", "Ticket Details ");
			} else {
				mv.addObject("message", "No Ticket found");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","viewBooking() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	@RequestMapping("/modifyTicket")
	public ModelAndView modifyTicket(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		try {
			BookingInformationBean bean=arsService.displayBooking(bookingId);
			mv.setViewName("modifyTicket");
			if (bean!=null) {
				
				mv.addObject("bean", bean);
				mv.addObject("message", "Ticket Details ");
			} else {
				mv.addObject("message", "No Ticket found");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","viewBooking() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
		
}
